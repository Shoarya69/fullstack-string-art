from cryptography.fernet import Fernet
import json
from app.All_sec import ENCsettings

enc = ENCsettings()

cipher = Fernet(enc.key.encode())

def decrypt_payload(enc_str: str) -> dict:
    decrypted_bytes = cipher.decrypt(enc_str.encode())
    return json.loads(decrypted_bytes.decode())
