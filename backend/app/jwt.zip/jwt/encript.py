from cryptography.fernet import Fernet
import json
from app.All_sec import ENCsettings

enc = ENCsettings()

SEC_key = enc.key.encode()
cipher = Fernet(SEC_key)

def Enc_playload(user_id: int,username : str, Type : str):
    data = {
    "user_id": user_id,
    "username": username,
    "Type": Type
    }

    encrypted_data = cipher.encrypt(
        json.dumps(data).encode()
    )

    return  encrypted_data.decode()